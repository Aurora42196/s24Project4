//
//  Revision.cpp
//  s24Project4
//
//  Created by Cameron Maiden on 6/10/24.
//

#include "Revision.h"
#include <iostream>
#include <fstream>

using namespace std;

void createRevision(istream& fold, istream& fnew, ostream& frevision)
{
    
}

bool revise(istream& fold, istream& frevision, ostream& fnew)
{
    return false;
}

